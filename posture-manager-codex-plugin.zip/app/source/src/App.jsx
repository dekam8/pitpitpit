import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell,
  Check,
  Clock3,
  Coffee,
  Maximize2,
  Minimize2,
  Moon,
  RotateCcw,
  Settings,
  SkipForward,
  TimerReset,
  UserRoundCheck,
} from 'lucide-react';

const STORAGE_KEY = 'postureManager_v1';

const INTERVALS = [
  { label: '10초', value: 10 },
  { label: '30초', value: 30 },
  { label: '1분', value: 60 },
  { label: '50분', value: 3000 },
];

const DEFAULT_SETTINGS = {
  interval: 3000,
  quietMode: false,
  widgetSize: 'normal',
  miniMode: false,
  lunchEnabled: true,
  lunchTime: '12:30',
  dinnerEnabled: true,
  dinnerTime: '18:30',
};

const DEFAULT_DATA = {
  healthScore: 0,
  completeCount: 0,
  skipCount: 0,
  snoozeCount: 0,
  standCount: 0,
  mealReminderShown: {
    lunch: false,
    dinner: false,
  },
};

const REMINDER_MESSAGES = [
  '50분 지났어요. 고개 한번 들어볼까요?',
  '오래 앉아 있었어요. 같이 한번 일어나요.',
  '우리 조금 뻐근해졌어요. 30초만 움직여요.',
  '어깨가 굳었어요. 천천히 돌려볼까요?',
];

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function clampScore(score) {
  return Math.max(-10, Math.min(10, score));
}

function formatTime(seconds) {
  const safeSeconds = Math.max(0, seconds);
  const minutes = Math.floor(safeSeconds / 60);
  const remainingSeconds = safeSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}

function getCharacterState(score) {
  if (score >= 6) return 'energised';
  if (score >= 1) return 'normal';
  if (score >= -2) return 'stiff';
  if (score >= -6) return 'heavy';
  return 'tired';
}

function getStateLabel(state) {
  return {
    energised: '가뿐해요',
    normal: '괜찮아요',
    stiff: '조금 뻐근해요',
    heavy: '몸이 무거워요',
    tired: '쉬고 싶어요',
  }[state];
}

function getInitialStore() {
  const fallback = {
    lastActiveDate: todayKey(),
    ...DEFAULT_DATA,
    settings: DEFAULT_SETTINGS,
  };

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;

    const parsed = JSON.parse(raw);
    const savedSettings = { ...DEFAULT_SETTINGS, ...(parsed.settings || {}) };
    const merged = {
      ...fallback,
      ...parsed,
      settings: savedSettings,
      mealReminderShown: {
        ...DEFAULT_DATA.mealReminderShown,
        ...(parsed.mealReminderShown || {}),
      },
    };

    if (merged.lastActiveDate !== todayKey()) {
      return {
        ...merged,
        ...DEFAULT_DATA,
        lastActiveDate: todayKey(),
      };
    }

    return merged;
  } catch {
    return fallback;
  }
}

function getMealWindow(settings, shown) {
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const meals = [
    { key: 'lunch', enabled: settings.lunchEnabled, time: settings.lunchTime, label: '점심' },
    { key: 'dinner', enabled: settings.dinnerEnabled, time: settings.dinnerTime, label: '저녁' },
  ];

  return meals.find((meal) => {
    if (!meal.enabled || shown[meal.key]) return false;
    const [hour, minute] = meal.time.split(':').map(Number);
    const mealMinutes = hour * 60 + minute;
    return currentMinutes >= mealMinutes && currentMinutes <= mealMinutes + 30;
  });
}

function App() {
  const [store, setStore] = useState(getInitialStore);
  const [remaining, setRemaining] = useState(store.settings.interval);
  const [isReminderActive, setIsReminderActive] = useState(false);
  const [reminderType, setReminderType] = useState('work');
  const [activeMeal, setActiveMeal] = useState(null);
  const [message, setMessage] = useState('작업을 시작해볼까요? 저는 옆에서 조용히 지켜볼게요.');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const reminderStartedAt = useRef(null);
  const characterState = getCharacterState(store.healthScore);
  const ignoreDelay = store.settings.interval === 3000 ? 120 : 10;
  const conditionPercent = ((store.healthScore + 10) / 20) * 100;

  const persistStore = (updater) => {
    setStore((current) => {
      const next = typeof updater === 'function' ? updater(current) : updater;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      return next;
    });
  };

  const updateScore = (delta) => {
    persistStore((current) => ({
      ...current,
      healthScore: clampScore(current.healthScore + delta),
    }));
  };

  const resetTimer = (seconds = store.settings.interval) => {
    setRemaining(seconds);
    setIsReminderActive(false);
    reminderStartedAt.current = null;
    setReminderType('work');
    setActiveMeal(null);
  };

  const showReminder = (type = 'work', meal = null) => {
    if (isReminderActive) return;
    setReminderType(type);
    setActiveMeal(meal);
    setIsReminderActive(true);
    reminderStartedAt.current = Date.now();
    setMessage(
      type === 'meal'
        ? `${meal.label} 먹고 바로 앉기 전에 5분만 걸어볼까요?`
        : REMINDER_MESSAGES[Math.floor(Math.random() * REMINDER_MESSAGES.length)],
    );
  };

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  }, [store]);

  useEffect(() => {
    if (isReminderActive) return;

    const timer = window.setInterval(() => {
      setRemaining((current) => {
        if (current <= 1) {
          showReminder('work');
          return 0;
        }
        return current - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [isReminderActive, store.settings.interval]);

  useEffect(() => {
    const checker = window.setInterval(() => {
      const today = todayKey();
      persistStore((current) => {
        if (current.lastActiveDate === today) return current;
        return {
          ...current,
          ...DEFAULT_DATA,
          lastActiveDate: today,
        };
      });
    }, 60_000);

    return () => window.clearInterval(checker);
  }, []);

  useEffect(() => {
    const mealChecker = window.setInterval(() => {
      if (isReminderActive) return;
      const meal = getMealWindow(store.settings, store.mealReminderShown);
      if (meal) showReminder('meal', meal);
    }, 30_000);

    return () => window.clearInterval(mealChecker);
  }, [isReminderActive, store.settings, store.mealReminderShown]);

  useEffect(() => {
    if (!isReminderActive) return;

    const watcher = window.setInterval(() => {
      if (!reminderStartedAt.current) return;
      const elapsed = Math.floor((Date.now() - reminderStartedAt.current) / 1000);
      if (elapsed >= ignoreDelay) {
        persistStore((current) => ({
          ...current,
          skipCount: current.skipCount + 1,
          healthScore: clampScore(current.healthScore - 1),
          mealReminderShown:
            reminderType === 'meal' && activeMeal
              ? { ...current.mealReminderShown, [activeMeal.key]: true }
              : current.mealReminderShown,
        }));
        setMessage('괜찮아요. 다음 알림 때 30초만 같이 움직여봐요.');
        resetTimer();
      }
    }, 1000);

    return () => window.clearInterval(watcher);
  }, [isReminderActive, ignoreDelay, reminderType, activeMeal]);

  const stats = useMemo(
    () => [
      { label: '완료', value: store.completeCount },
      { label: '스킵', value: store.skipCount },
      { label: '미루기', value: store.snoozeCount },
      { label: '일어나기', value: store.standCount },
    ],
    [store.completeCount, store.skipCount, store.snoozeCount, store.standCount],
  );

  const updateSettings = (patch) => {
    persistStore((current) => ({
      ...current,
      settings: {
        ...current.settings,
        ...patch,
      },
    }));

    if (patch.interval) {
      setRemaining(patch.interval);
      setIsReminderActive(false);
      reminderStartedAt.current = null;
    }
  };

  const markMealShown = (current) => {
    if (reminderType !== 'meal' || !activeMeal) return current.mealReminderShown;
    return { ...current.mealReminderShown, [activeMeal.key]: true };
  };

  const handleComplete = () => {
    persistStore((current) => ({
      ...current,
      completeCount: current.completeCount + 1,
      standCount: reminderType === 'meal' ? current.standCount + 1 : current.standCount,
      healthScore: clampScore(current.healthScore + (reminderType === 'meal' ? 2 : 1)),
      mealReminderShown: markMealShown(current),
    }));
    setMessage(
      reminderType === 'meal'
        ? '좋아요. 잠깐 걸었더니 몸이 훨씬 가벼워졌어요.'
        : '좋아요! 움직였더니 훨씬 가벼워졌어요.',
    );
    resetTimer();
  };

  const handleSnooze = () => {
    persistStore((current) => ({
      ...current,
      snoozeCount: current.snoozeCount + 1,
    }));
    setMessage('괜찮아요. 조금 뒤에 다시 살짝 알려줄게요.');
    resetTimer(store.settings.interval === 3000 ? 300 : Math.max(5, Math.floor(store.settings.interval / 2)));
  };

  const handleSkip = () => {
    persistStore((current) => ({
      ...current,
      skipCount: current.skipCount + 1,
      healthScore: clampScore(current.healthScore - 1),
      mealReminderShown: markMealShown(current),
    }));
    setMessage('우리 조금 뻐근해졌어요. 다음엔 30초만 같이 움직여요.');
    resetTimer();
  };

  const handleStand = () => {
    persistStore((current) => ({
      ...current,
      standCount: current.standCount + 1,
      healthScore: clampScore(current.healthScore + 2),
      mealReminderShown: markMealShown(current),
    }));
    setMessage('좋아요. 일어났더니 몸이 훨씬 가벼워졌어요.');
    resetTimer();
  };

  const resetData = () => {
    const next = {
      ...store,
      ...DEFAULT_DATA,
      lastActiveDate: todayKey(),
    };
    persistStore(next);
    setMessage('오늘 기록을 새로 시작했어요.');
    resetTimer(store.settings.interval);
  };

  return (
    <main className={`page-shell ${store.settings.miniMode ? 'mini-page' : ''}`}>
      <section
        className={`widget ${store.settings.widgetSize} ${store.settings.quietMode ? 'quiet' : ''} ${
          store.settings.miniMode ? 'mini-character' : ''
        }`}
      >
        <header className="widget-header">
          <div>
            <p className="eyebrow">Posture Manager</p>
            <h1>같이 몸을 챙겨요</h1>
          </div>
          <div className="header-actions">
            <button
              className="icon-button"
              type="button"
              onClick={() => updateSettings({ miniMode: !store.settings.miniMode })}
              aria-label={store.settings.miniMode ? '전체 위젯 보기' : '캐릭터만 보기'}
              title={store.settings.miniMode ? '전체 위젯 보기' : '캐릭터만 보기'}
            >
              {store.settings.miniMode ? <Maximize2 size={17} /> : <Minimize2 size={17} />}
            </button>
            <button
              className="icon-button"
              type="button"
              onClick={() => setSettingsOpen((open) => !open)}
              aria-label="설정 열기"
              title="설정"
            >
              <Settings size={18} />
            </button>
          </div>
        </header>

        <div className={`character-zone ${characterState}`}>
          <div className="speech-row">
            <div className={`speech ${isReminderActive ? 'active' : ''}`}>
              {isReminderActive && <Bell size={15} />}
              <span>{message}</span>
            </div>
          </div>

          <button
            className="character-stage"
            type="button"
            onClick={() => {
              if (store.settings.miniMode) updateSettings({ miniMode: false });
            }}
            aria-label={`현재 상태 ${getStateLabel(characterState)}`}
            title={store.settings.miniMode ? '전체 위젯 보기' : getStateLabel(characterState)}
          >
            <div className={`character ${characterState}`}>
              <div className="head">
                <div className="face">
                  <span className="eye left-eye" />
                  <span className="eye right-eye" />
                  <span className="mouth" />
                </div>
              </div>
              <span className="arm left-arm" />
              <span className="arm right-arm" />
              <div className="body">
                <span className="breath-mark" />
              </div>
              <span className="leg left-leg" />
              <span className="leg right-leg" />
            </div>
          </button>
        </div>

        <section className="status-panel">
          <div>
            <p className="panel-label">현재 컨디션</p>
            <strong>{getStateLabel(characterState)}</strong>
          </div>
          <div className="timer-block">
            <Clock3 size={17} />
            <span>{formatTime(remaining)}</span>
          </div>
        </section>

        <div className="condition-meter" aria-label="컨디션 점수">
          <div className="meter-track">
            <span style={{ width: `${conditionPercent}%` }} />
          </div>
          <div className="meter-labels">
            <span>쉬기</span>
            <span>가뿐함</span>
          </div>
        </div>

        {isReminderActive && (
          <div className="action-grid">
            <button type="button" onClick={handleComplete}>
              <Check size={16} />
              완료
            </button>
            <button type="button" onClick={handleSnooze}>
              <TimerReset size={16} />
              5분 뒤
            </button>
            <button type="button" onClick={handleSkip}>
              <SkipForward size={16} />
              스킵
            </button>
            <button type="button" onClick={handleStand}>
              <UserRoundCheck size={16} />
              일어났어요
            </button>
          </div>
        )}

        <section className="today-panel">
          <div className="section-title">
            <span>오늘 기록</span>
            <small>{todayKey()}</small>
          </div>
          <div className="stats-grid">
            {stats.map((item) => (
              <div className="stat" key={item.label}>
                <span>{item.label}</span>
                <strong>{item.value}</strong>
              </div>
            ))}
          </div>
          <div className="current-state">
            <span>현재 상태</span>
            <strong>{getStateLabel(characterState)}</strong>
          </div>
        </section>

        {settingsOpen && (
          <section className="settings-panel">
            <div className="section-title">
              <span>설정</span>
              <small>자동 저장</small>
            </div>

            <label className="field">
              <span>알림 간격</span>
              <select
                value={store.settings.interval}
                onChange={(event) => updateSettings({ interval: Number(event.target.value) })}
              >
                {INTERVALS.map((option) => (
                  <option value={option.value} key={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </label>

            <div className="toggle-row">
              <label>
                <input
                  type="checkbox"
                  checked={store.settings.quietMode}
                  onChange={(event) => updateSettings({ quietMode: event.target.checked })}
                />
                <Moon size={15} />
                조용한 모드
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={store.settings.widgetSize === 'compact'}
                  onChange={(event) =>
                    updateSettings({ widgetSize: event.target.checked ? 'compact' : 'normal' })
                  }
                />
                컴팩트
              </label>
            </div>

            <div className="meal-grid">
              <label className="meal-toggle">
                <input
                  type="checkbox"
                  checked={store.settings.lunchEnabled}
                  onChange={(event) => updateSettings({ lunchEnabled: event.target.checked })}
                />
                <Coffee size={15} />
                점심 산책
              </label>
              <input
                type="time"
                value={store.settings.lunchTime}
                onChange={(event) => updateSettings({ lunchTime: event.target.value })}
              />
              <label className="meal-toggle">
                <input
                  type="checkbox"
                  checked={store.settings.dinnerEnabled}
                  onChange={(event) => updateSettings({ dinnerEnabled: event.target.checked })}
                />
                <Coffee size={15} />
                저녁 산책
              </label>
              <input
                type="time"
                value={store.settings.dinnerTime}
                onChange={(event) => updateSettings({ dinnerTime: event.target.value })}
              />
            </div>

            <button className="reset-button" type="button" onClick={resetData}>
              <RotateCcw size={16} />
              오늘 데이터 초기화
            </button>
          </section>
        )}
      </section>
    </main>
  );
}

export default App;
