# Floating Posture Manager MVP

A small React + Vite widget for people who work at a computer for long sessions. It uses a supportive character, timer reminders, and gentle Korean copy to help the user notice posture, stretching, standing, and short meal walks.

## Features

- Floating widget UI sized for a coding workspace
- CSS character with visible states: energised, normal, stiff, heavy, tired
- `healthScore` from `-10` to `+10` drives the character condition
- Work timer with test intervals: 10 seconds, 30 seconds, 1 minute, 50 minutes
- Reminder actions: `완료`, `5분 뒤`, `스킵`, `일어났어요`
- Automatic unanswered skip after 10 seconds in test modes or 2 minutes in 50-minute mode
- Today's records for completion, skip, snooze, standing, and current state
- Daily reset using `lastActiveDate`
- Optional lunch and dinner walk reminders
- Quiet mode and compact widget settings
- Character-only mini mode for keeping the manager visually small
- localStorage persistence under `postureManager_v1`

## Run

```bash
npm install
npm run dev
```

Then open the localhost URL printed by Vite.

## Build

```bash
npm run build
```

## Quick Test

1. Open the settings panel.
2. Change the reminder interval to `10초`.
3. Wait for the timer to reach `00:00`.
4. Try `완료`, `5분 뒤`, `스킵`, and `일어났어요`.
5. Leave a reminder unanswered for 10 seconds to test the automatic skip behavior.

## localStorage

The app stores data in:

```js
postureManager_v1
```

Stored data includes:

- `lastActiveDate`
- `healthScore`
- `completeCount`
- `skipCount`
- `snoozeCount`
- `standCount`
- `mealReminderShown`
- `settings`

Daily records reset when the date changes. Settings are preserved.

## Known Limitations

- No browser notification permission or sound support.
- Meal reminders are checked while the app is open.
- The MVP uses localStorage only, so data is browser-specific.
- A browser-based web app cannot stay always-on-top above Codex or other desktop apps by itself. True OS-level floating behavior needs a desktop wrapper such as Electron or Tauri with an always-on-top window.
