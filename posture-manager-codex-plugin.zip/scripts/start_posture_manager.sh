#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="$ROOT_DIR/app/dist"
HOST="${POSTURE_MANAGER_HOST:-127.0.0.1}"
START_PORT="${POSTURE_MANAGER_PORT:-5173}"

if [ ! -f "$DIST_DIR/index.html" ]; then
  echo "Posture Manager build is missing: $DIST_DIR/index.html" >&2
  exit 1
fi

port="$START_PORT"
attempts=0
while ! python3 - "$HOST" "$port" <<'PY'
import socket
import sys

host = sys.argv[1]
port = int(sys.argv[2])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
    try:
        sock.bind((host, port))
    except OSError:
        raise SystemExit(1)
PY
do
  attempts=$((attempts + 1))
  if [ "$attempts" -ge 40 ]; then
    echo "Could not find an available local port starting from $START_PORT." >&2
    exit 1
  fi
  port=$((port + 1))
done

echo "Posture Manager: http://$HOST:$port/"
python3 -m http.server "$port" --bind "$HOST" --directory "$DIST_DIR"
