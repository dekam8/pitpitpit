---
name: posture-manager
description: Use when the user wants to open, run, test, package, or modify the local Posture Manager widget plugin/app for Codex work sessions.
---

# Posture Manager

This plugin contains a local React + Vite posture manager widget.

## App Locations

- Built static app: `app/dist/`
- Source app: `app/source/`
- Start script: `scripts/start_posture_manager.sh`

## Run The Widget

Prefer the bundled start script from the plugin root:

```bash
scripts/start_posture_manager.sh
```

The script serves `app/dist` on `http://127.0.0.1:5173/` by default and falls back to another available port if needed.

If the user wants the app visible, open the local URL in the Codex in-app browser.

## Product Notes

- The web app runs inside a browser tab or local webview.
- Character-only mini mode is available inside the browser view.
- A browser-only app cannot stay above all other desktop windows.
- True always-on-top behavior requires a desktop wrapper such as Electron or Tauri.

## Build Or Update

If modifying the source app:

```bash
cd app/source
npm install
npm run build
```

Then copy the resulting `dist/` into `app/dist/` before validating or sharing the plugin.
