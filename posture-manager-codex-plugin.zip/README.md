# Posture Manager Codex Plugin

Posture Manager is a local Codex plugin that bundles a React posture reminder widget.

## Included

- Codex plugin manifest
- Posture Manager skill
- Static web build
- React source app
- Local start script

## Run

From the plugin root:

```bash
scripts/start_posture_manager.sh
```

Then open the printed local URL.

## Limitations

This plugin packages the widget for Codex discovery and local use. It does not make the widget an operating-system always-on-top desktop window. For that behavior, package the app with Electron or Tauri.
